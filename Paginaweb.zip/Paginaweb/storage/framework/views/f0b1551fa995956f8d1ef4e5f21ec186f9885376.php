<header>

	<!--
	<div class="menu_bar">
		<a href="#" class="bt-menu"><span class="icon-list2">Menu</span></a>
	</div>
	-->

	<!--- <nav>
		<ul>
			<li><a href="#"><span class="icon-">Inicio</a></span></li>
			<li><a href="#"><span class="icon-">Trabajos</a></span></li>
			<li><a href="#"><span class="icon-">Proyectos</a></span></li>
			<li><a href="#"><span class="icon-">Servicios</a></span></li>
			<li><a href="#"><span class="icon-">Contactos</a></span></li>
		</ul>
	</nav> -->

	    <nav class="navbar navbar-default navbar-fixed-top" data-target=".navbar-collapse">
	        <div class="container">
	          <!-- Brand and toggle get grouped for better mobile display -->
	          <div class="navbar-header">
	            <a class="navbar-brand" href="/">
		          <img id="logo" alt="logo" src="<?php echo e(URL::asset('img/logo-imagen.png')); ?>">
		          <img id="texto" alt="nombre" src="<?php echo e(URL::asset('img/logomun-texto.png')); ?>">
	            </a>
	           
	           	<div class="menu_bar navbar-toggle collapsed">
					<!-- <a href="#" class="bt_menu"><span class="icon-list2">Menu</span></a> -->
					<!--
			            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-2" aria-expanded="false">
			              <span class="sr-only">Toggle navigation</span>
			              <span class="icon-bar"></span>
			              <span class="icon-bar"></span>
			              <span class="icon-bar"></span>
			            </button>
			            -->
			            <a href="#" class="bt_menu" data-toggle="collapse" data-target="#bs-example-navbar-collapse-2" aria-expanded="false">
			            	<span class="icon-list2">
			              <span class="sr-only">Toggle navigation</span>
			              <span class="icon-bar"></span>
			              <span class="icon-bar"></span>
			              <span class="icon-bar"></span>
			              </span>
			            </a>

			            <!--<a href="#" class="bt_menu"><span class="icon-list2">Menu</span></a> -->

	            </div>

	            	<!--<div class="menu_bar">
						<a href="#" class="bt-menu"><span class="icon-list2">Menu</span></a>
					</div>
					-->
	          </div>

	          <!-- Collect the nav links, forms, and other content for toggling -->
	          <div class="lista-navbar" id="bs-example-navbar-collapse-1">
	            <ul class="nav navbar-nav navbar-right">

	              <li <?php echo $__env->yieldContent('inicio'); ?>><a href="/">Inicio<span class="sr-only">(current)</span></a></li>
	              <?php if( Auth::check() ): ?>
	              	<?php if( Auth::user()->idrol === 1 ): ?>
	                	<li <?php echo $__env->yieldContent('miarea'); ?>><a class="area" href="/busqueda">Mi área</a></li>
	                <?php elseif( Auth::user()->idrol === 2): ?>
	                	<?php if( Auth::user()->estado == "inactivo" ): ?>
	                		<!-- Modal -->
	                		<li><a data-toggle="modal" data-target="#aviso" href="#">Mis publicaciones</a></li>
	                	<?php else: ?>
	                		<li <?php echo $__env->yieldContent('publicacion'); ?>><a class="publicaciones" href="/publicacion">Mis publicaciones</a></li>
	                	<?php endif; ?>
	                <?php elseif( Auth::user()->idrol === 3): ?>
	                	<li <?php echo $__env->yieldContent('admin'); ?>><a class="admin" href="/admin">Panel de control</a></li>
	                <?php endif; ?>
	              <?php endif; ?>
	              <!-- <li <?php echo $__env->yieldContent('servicios'); ?>><a href="/servicios">Servicios</a></li>  -->
	              <?php if( !Auth::check() ): ?>
	                <li <?php echo $__env->yieldContent('registro'); ?>><a data-toggle="modal" data-target="#myModal" id="registro-user" href="#">Registro</a></li>
	              <?php endif; ?>

	              <li <?php echo $__env->yieldContent('contacto'); ?>><a href="/contacto">Contacto</a></li>
	              <?php if( Auth::check() ): ?>
	              	<li class="dropdown">
	                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
	                        <i class="fa fa-user fa-fw"></i>  <?php echo e(Auth::user()->email); ?> <i class="fa fa-caret-down"></i>
	                    </a>
	                    <ul class="dropdown-menu dropdown-user">
	                        <li><a data-toggle="modal" data-target="#myModalConfiguracion" href="#"><i class="fa fa-gear fa-fw"></i> Configuracion</a></li>
	                        <li class="divider"></li>
	                        <li><a href="/logout"><i class="fa fa-sign-out fa-fw"></i> Cerrar sesión</a>
	                        </li>
	                    </ul>
	                    <!-- /.dropdown-user -->
                	</li>

                	<!--
	                <li>
	                  <div class="dropdown">
	                <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown" id="btn-correo">

	                
	                <span class="caret"></span></button>
	                <ul class="dropdown-menu">
		                            
	                  <li><a data-toggle="modal" data-target="#myModalConfiguracion" href="#">Configuracion</a></li>
	                  <li><a href="/logout">Cerrar sesión</a></li>
	                </ul>
	              </div>
	            </li>
	            -->
	                <!-- <li><a href="/salir">Salir</a></li> -->
	              <?php endif; ?>

	            </ul>
	          </div><!-- /.navbar-collapse -->
	        </div><!-- /.container-fluid -->
	    </nav>
	</header>



<?php if( Auth::check() && Auth::user()->estado == "inactivo"): ?>
	<div class="modal fade" id="aviso" role="dialog">
	    <div class="modal-dialog modal-sm">
	      <div class="modal-content">
	        <div class="modal-header">
	          <button type="button" class="close" data-dismiss="modal">&times;</button>
	          <h4 class="modal-title text-center">Notificación</h4>
	        </div>
	        <div class="modal-body text-center">
	        	<h4>Espera confirmación</h4>
	          	<h5><p>Debes esperar la aprobación del administrador antes de publicar, te enviaremos un correo electronico para informarte cuando puedas publicar...</p>
	          	</h5>
	        </div>
	        <div class="modal-footer">
	          <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
	        </div>
	      </div>
	    </div>
	  </div>
	</div>
<?php endif; ?>


<?php if( !Auth::check() ): ?>
  <!-- Modal -->
  <div id="myModal" class="modal fade" role="dialog">
    <div class="modal-dialog" id="modal-ocultar">

      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" id="close-user-form" class="close" data-dismiss="modal">&times;</button>
          <h4 class="text-center modal-title">Registrate en Mundocente</h4>
        </div>


       <!-- <form role="form" action="registro" method="post"> -->
          <div class="modal-body">
            <?php echo $__env->make('alerts.request', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('alerts.success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <?php echo $__env->make('usuario.forms.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

          </div>

            <!--<div class="modal-footer">
              <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
              <button type="submit" class="btn btn-primary">Registrar</button>
            </div>
            -->
        </div>
      <!-- </form> -->

    </div>
  </div>

 <?php endif; ?>

 <?php if( Auth::check() ): ?>

<!-- Modal -->
  <div id="myModalConfiguracion" class="modal fade" role="dialog">
    <div class="modal-dialog">

      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="text-center modal-title"> Configuración de la cuenta</h4>
        </div>

        

       <!-- <form role="form" action="registro" method="post"> -->
          <div class="modal-body">
            <div id="error-admin"></div>

            <?php if( Auth::user()->idrol == 3): ?>

            	<?php if(isset($user)): ?>

					<?php echo Form::model($user, ['route'=>['usuario.update', $user->id], 'method'=>'put','name'=>'formularioAdmin','onsubmit'=>'return false;','class'=>'formularioAdmin']); ?>


					<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" id="token"/>
						<?php echo $__env->make('alerts.request', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
						<?php echo $__env->make('alerts.success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

						<?php echo $__env->make('usuario.forms.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

					<div class="modal-footer">
							<button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
							<?php echo Form::submit('Actualizar', ['class'=>'submit-editar-admin btn btn-primary']); ?>

					</div>

					<?php echo Form::close(); ?>

				<?php endif; ?>
			<?php else: ?>
            	<?php echo $__env->make('usuario.forms.editar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php endif; ?>

          </div>

          	<!--
            <div class="modal-footer">
              <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
              <button type="submit" class="btn btn-primary">Registrar</button>
            </div>
            -->
        </div>
      <!-- </form> -->

    </div>
  </div>
<?php endif; ?>