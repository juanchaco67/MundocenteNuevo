<?php $__env->startSection('titulo-pagina'); ?>
	Usuarios
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
	<?php echo $__env->make('alerts.success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	
	<?php if(isset($usuarios)): ?>
		<?php if(count($usuarios)>0): ?>
			<table class="table">
				<thead>
					<th>Nombre</th>
					<th>Correo</th>
					<th>Rol</th>
					<th>Estado</th>
					<th>Operación</th>
				</thead>
				<?php foreach($usuarios as $usu): ?>
					<?php if($usu->estado == 'activo'): ?>
						<tbody>
							<th><?php echo e($usu->name); ?></th>
							<th><?php echo e($usu->email); ?></th>
							<th><?php echo e($usu->idrol); ?></th>
							<th><?php echo e($usu->estado); ?></th>
							<th>
								<?php echo link_to_route('admin.edit', $title = 'Editar', $parameters = $usu->id, $atrributes = ['class' => 'btn btn-primary', 'title'=>'Editar datos de este usuario']); ?>

							</th>
						</tbody>
					<?php endif; ?>
				<?php endforeach; ?>
			</table>

			<h4 class="text-center">Total en esta página: <?php echo e(count($usuarios)); ?></h4>
			<?php echo $usuarios->render(); ?>



		<?php else: ?>
			<h3 class="text-center">No tiene usuarios registrados</h3>
			<div class="row">
			    <div class="col-md-2 col-md-offset-5">
			    	<div class="form-group">
						<a href="/usuario/create" class="form-control btn btn-primary" title="Registrar un nuevo usuario">Crear nuevo</a>
					</div>
			    </div>
			</div>			
		<?php endif; ?>
	<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.paneladmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>