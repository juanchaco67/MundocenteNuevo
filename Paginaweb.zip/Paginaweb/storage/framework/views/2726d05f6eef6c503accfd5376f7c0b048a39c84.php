<?php $__env->startSection('titulo'); ?>
	Admin
<?php $__env->stopSection(); ?>

<?php $__env->startSection('panel'); ?>
	<?php echo $__env->make('layouts.paneladmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('titulo-pagina'); ?>
	Panel de administración
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
	<!-- <h3 class="text-center">Bienvenido <?php echo e($user->name); ?></h3> -->
	<h3 class="text-center">Listado de activaciones pendientes</h3>
	<?php if(isset($pendientes)): ?>
		<?php if($pendientes): ?>
			<table class="table">
				<thead>
					<th>Nombre</th>
					<th>Correo</th>
					<th>Rol</th>
					<th>Estado</th>
					<th>Operación</th>
				</thead>
				<?php foreach($pendientes as $pendiente): ?>
					<tbody>
						<th><?php echo e($pendiente->name); ?></th>
						<th><?php echo e($pendiente->email); ?></th>
						<th><?php echo e($pendiente->idrol); ?></th>
						<th><?php echo e($pendiente->estado); ?></th>
						<th>
							<?php echo link_to_route('admin.edit', $title = 'Editar', $parameters = $pendiente->id, $atrributes = ['class' => 'btn btn-primary']); ?>

							<?php echo link_to_route('admin.edit', $title = 'Activar', $parameters = $pendiente->id, $atrributes = ['class' => 'btn btn-primary']); ?>

						</th>
					</tbody>
				<?php endforeach; ?>
			</table>
		<?php else: ?>
			<h4 class="text-center">No tiene activaciones pendientes</h4>
		<?php endif; ?>
	<?php endif; ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>