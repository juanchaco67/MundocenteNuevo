<input name="rol" value="docente" id="rol"  hidden></input>
<?php echo $__env->make('usuario.forms.registro', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="form-group">
		<label for="notificar">Recibir notificaciones</label>
		<?php if(isset($usuario)): ?>
			<?php if($usuario->docente): ?>
				<?php if($usuario->docente->notificar === 0): ?>
					<?php echo Form::checkbox('notificar', '1', true,array('class'=>'campo_checkbox','name'=>'notificar')); ?>

				<?php else: ?>
					<?php echo Form::checkbox('notificar', '1', false,array('class'=>'campo_checkbox','name'=>'notificar')); ?>

				<?php endif; ?>
			<?php endif; ?>
		<?php else: ?>
			<?php echo Form::checkbox('notificar', '0', true,array('class'=>'campo_checkbox','name'=>'notificar')); ?>

		<?php endif; ?>
	</div>		
			
	<div class="form-group">
			<?php if(isset($areas)): ?>
			<legend>Areas de interés</legend>					
			<select  id="area-publicacion-docente" class="form-control">
				<?php foreach($areas as $area): ?>
		  		<option value="<?php echo e($area->id); ?>" name="<?php echo e($area->nombre); ?>"><?php echo e($area->nombre); ?></option>
				<?php endforeach; ?>
			</select>		
			<?php else: ?>
			<h1>Sin areas</h1>
			<?php endif; ?>					
	</div>				

<?php if(isset($verificar)): ?>
  <div class="scrollbar areas-aparecer-docente-scroll" id="style-1" style="display:inline-block;">
  
<div id="areas-aparecer-docente" class="force-overflow" style="display:inline-block; width:100%; height:30px;">

	<?php foreach($areas as $area): ?>

		<?php if(in_array($area->id, $areas_publicacion)): ?>
					<div style="height:1px;display:inline-block;position:relative;" class="alert alert-success"><span style="position:relative;bottom:10px;"><?php echo e($area->nombre); ?></span><a style="position:absolute;left:90%;top:0%;" href="#" id="area-aparecer-docente<?php echo e($area->id); ?>" class="eliminar-docente close" data-dismiss="alert" aria-label="close">&times;</a></div>
					 <input type="hidden" name="areas[]" class="areas-eliminar-hidden" id="hidden-docente-<?php echo e($area->id); ?>" value="<?php echo e($area->id); ?>"/>
			
				<?php endif; ?>
	<?php endforeach; ?>
</div>	 
</div>	    	
 <?php else: ?>
  <div class="scrollbar areas-aparecer-docente-scroll" id="style-1" style="display:none;">
  
<div id="areas-aparecer-docente" class="force-overflow" style="display:none; width:100%; height:30px;">

</div>
</div>

 <?php endif; ?>
	
<?php if(isset($usuario)): ?>
	<?php if($usuario->estado == "activo"): ?>
		<div class="form-group">
			<label for="desactivar">Desactivar esta cuenta</label>
			<?php if($usuario->estado === 'inactivo'): ?>
				<input name="desactivar" id="" value="desactivar" type="checkbox" checked></input>
			<?php else: ?>
				<input name="desactivar" id="desactivar" value="desactivar" type="checkbox"></input>
			<?php endif; ?>
		</div>
	<?php else: ?>
		<div class="form-group">
			<label for="activar">Activar esta cuenta</label>
			<?php if($usuario->estado === 'activo'): ?>
				<input name="activar" id="" value="activar" type="checkbox" checked></input>
			<?php else: ?>
				<input name="activar" id="activar" value="activar" type="checkbox"></input>
			<?php endif; ?>
		</div>
	<?php endif; ?>
<?php /*
	<?php if($usuario->estado === 'activo'): ?>
		<div class="form-group">	
			<label for="desactivar">Desactivar esta cuenta</label>
			<?php if($usuario->estado === 'inactivo'): ?>
				<input id="desactivar" name="desactivar" value="desactivar" type="checkbox" checked></input>
			<?php else: ?>
				<input id="desactivar" name="desactivar" value="desactivar" type="checkbox"></input>
			<?php endif; ?>
		</div>
	<?php endif; ?>
*/ ?>
<?php endif; ?>
