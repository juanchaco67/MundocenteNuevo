<?php if(Session::has('mensaje-error')): ?>
	<div class="alert alert-danger alert-dismissible" role="alert">
		<button type="button" class="close" data-dismiss="alert" aria-label="Close">
			<span aria-hidden="true">&times;</span>
		</button>
		<?php echo e(Session::get('mensaje-error')); ?>

	</div>
<?php endif; ?>