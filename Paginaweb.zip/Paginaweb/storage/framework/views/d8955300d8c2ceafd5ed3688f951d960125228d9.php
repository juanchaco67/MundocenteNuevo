<?php $__env->startSection('titulo-pagina'); ?>
	Establecimientos
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
	<?php echo $__env->make('alerts.success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<?php if(isset($establecimientos)): ?>
		<?php if($establecimientos): ?>
			<table class="table">
				<thead>
					<th>Nombre</th>
					<th>Estado</th>
					<th>Acciones</th>
				</thead>
					<?php foreach($establecimientos as $establecimiento): ?>
						<?php if($establecimiento->estado == 'activo'): ?>
							<?php echo $__env->make('establecimiento.listado', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
						<?php endif; ?>
					<?php endforeach; ?>
			</table>
			<div class="row">
			    <div class="col-md-2 col-md-offset-5">
			    	<div class="form-group">
						<a href="/establecimiento/create" class="form-control btn btn-primary" title="Crear una nueva Universidad/Entidad">Crear nuevo</a>
					</div>
			    </div>
			</div>	
		<?php else: ?>
			<h3 class="text-center">No tiene establecimientos</h3>
			<div class="row">
			    <div class="col-md-2 col-md-offset-5">
			    	<div class="form-group">
						<a href="/establecimiento/create" class="form-control btn btn-primary" title="Crear una nueva Universidad/Entidad">Crear nuevo</a>
					</div>
			    </div>
			</div>			
		<?php endif; ?>
	<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.paneladmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>