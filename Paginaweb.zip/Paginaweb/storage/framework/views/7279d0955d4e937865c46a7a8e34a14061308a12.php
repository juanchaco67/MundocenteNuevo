<div class="">
 
  	<ul class="nav nav-tabs">
	    <li class="active"><a data-toggle="tab" href="#docentes">Docentes</a></li>
    	<li><a data-toggle="tab" href="#funcionarios">Publicadores</a></li>
  	</ul>

 
    <div class="tab-content">
      <div id="docentes" class="tab-pane fade in active">

        <?php /* <?php echo $__env->make('alerts.request', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> */ ?>
          <!--<?php echo Form::open(['route'=>'usuario.store', 'method'=>'post','id'=>'formularioDocente','name'=>'formularioDocente']); ?>  
          -->
  
          <form action="<?php echo e(route('usuario.store')); ?>" method="post" id="formularioDocenteStore" class="formularioDocente" name="formularioDocente">
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" id="token"/>

            <?php echo $__env->make('usuario.forms.docente', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <div class="modal-footer">
              <!-- <?php echo Form::submit('Registrar', ['class'=>'btn btn-primary']); ?>

              <?php echo Form::submit('Cancelar', ['class'=>'btn btn-default']); ?>

              -->           

                <?php if(!Auth::check()): ?>
                  <button type="button" class="cancelar btn btn-default" data-dismiss="modal">Cancelar</button>
                <?php endif; ?>
                <button  class="submit-registrar-docente btn btn-primary" title="Registrar este usuario">Registrar</button>
                 
            </div>
            <!--<?php echo Form::close(); ?> -->
          </form>
      </div>
      <div id="funcionarios" class="tab-pane fade">
        <?php /* <?php echo $__env->make('alerts.request', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> */ ?>
        <!--
       <?php echo Form::open(['route'=>'usuario.store', 'method'=>'post','id'=>'formularioFuncionario']); ?> 
       -->
       <form action="<?php echo e(route('usuario.store')); ?>" method="post" class="formularioFuncionario" name="formularioFuncionario">
        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" id="toke"/>
          <?php echo $__env->make('usuario.forms.funcionario', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

          <div class="modal-footer">
            <!--
            <?php echo Form::submit('Registrar', ['class'=>'btn btn-primary']); ?>

            <?php echo Form::submit('Cancelar', ['class'=>'btn btn-default']); ?>

            -->
                <?php if(!Auth::check()): ?>
                  <button type="button" class="cancelar btn btn-default" data-dismiss="modal">Cancelar</button>
                <?php endif; ?>
                <button class="submit-registrar-funcionario btn btn-primary" title="Registrar este usuario">Registrar</button>
            <!-- <?php echo Form::close(); ?> -->
          </div>
        </form>
      </div>

    </div>
</div>
