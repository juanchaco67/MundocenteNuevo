<!DOCTYPE html>
<html>
<head>

    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <?php echo $__env->make('layouts.linksplantilla', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<meta charset="utf-8" />
	<?php echo Html::style('css/bootstrap.min.css'); ?>

	<?php echo Html::style('css/estilos.css'); ?>

	<!-- <script src="../js/jquery-1.12.3.min.js"></script> -->
	<link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/bootstrap.min.css')); ?>"> 
	<link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/estilos.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/estilo-menu.css')); ?>"> 

	<title>Mundocente | <?php echo $__env->yieldContent('titulo-pagina'); ?></title>
</head>

<body>
	<?php echo $__env->make('layouts.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<div class="">
			<?php echo $__env->yieldContent('superior'); ?>
	</div>

	<div class="cuerpo">

		<div class="paneles container">
			<?php echo $__env->yieldContent('titulo-contenido'); ?>
			<div class="panel-izquierdo col-xs-12 col-sm-12 col-md-3">

			    <?php echo $__env->yieldContent('panel'); ?>

			</div>		
		  	<div class="principal col-xs-12 col-sm-12 col-md-9">
				<div class="contenido">
					<?php echo $__env->yieldContent('contenido'); ?>
					<?php echo $__env->yieldContent('pie'); ?>
					
				</div>
			</div>
		</div>
	</div>


<footer>
<div class="container">
  <div class="bottom-footer">
    <h3>Desarrollo:</h3>
    <ul>
      <li>Deybi Pulido - <span class="small"> Back-End</span></li>
      <li>Sergio Piña - <span class="small"> Front-End</span></li>
      <li>Juan Rogriguez - <span class="small"> Aseguramiento de Calidad </span></li>
      <li>Sebastian Sarmiento - <span class="small"> Aseguramiento de Calidad</span></li>
    </ul>
    <div class="col-xs-12 col-sm-12 col-md-12">
      
    </div>
  </div>
</div>
</footer>

<!--
	<?php echo Html::style('js/jquery-1.12.3.min.js'); ?>

	<?php echo Html::style('js/bootstrap.min.js'); ?>

	<?php echo Html::style('js/main.js'); ?>


	-->

	<script type="text/javascript" src="<?php echo e(URL::asset('js/jquery-1.12.3.min.js')); ?>"></script>
	<script type="text/javascript" src="<?php echo e(URL::asset('js/bootstrap.min.js')); ?>"></script>
	<script type="text/javascript" src="<?php echo e(URL::asset('js/main.js')); ?>"></script>

	<script type="text/javascript" src="<?php echo e(URL::asset('js/formularios.js')); ?>"></script>

	<script type="text/javascript" src="<?php echo e(URL::asset('js/menu.js')); ?>"></script>

</body>
</html>