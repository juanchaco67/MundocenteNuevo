<?php $__env->startSection('titulo-pagina'); ?>
	Publicaciones
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
	<?php echo $__env->make('alerts.success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<?php if(isset($publicaciones)): ?>
		<?php if(count($publicaciones)>0): ?>
			<table class="table">
				<thead>
					<th>Nombre</th>
					<th>Resumen</th>
					<th>Tipo</th>
					<th>Fecha publicado</th>
					<th>Fecha cierre</th>
					<th>Acciones</th>
				</thead>
					<?php foreach($publicaciones as $publicacion): ?>
						<?php if($publicacion->estado == 'activa'): ?>
							<?php echo $__env->make('publicacion.listado', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
						<?php endif; ?>
					<?php endforeach; ?>
			</table>
			<div class="row">
			    <div class="col-md-2 col-md-offset-5">
			    	<div class="form-group">
						<a href="/publicacion/create" class="form-control btn btn-primary" title="Crear una nueva publicación">Crear nueva</a>
					</div>
			    </div>
			</div>	

			<h4 class="text-center">Total en esta página: <?php echo e(count($publicaciones)); ?></h4>
			<?php echo $publicaciones->render(); ?>

		<?php else: ?>
			<h3 class="text-center">No tiene publicaciones</h3>
			<div class="row">
			    <div class="col-md-2 col-md-offset-5">
			    	<div class="form-group">
						<a href="/publicacion/create" class="form-control btn btn-primary" title="Crear una nueva publicación">Crear nueva</a>
					</div>
			    </div>
			</div>			
		<?php endif; ?>
	<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.paneladmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>