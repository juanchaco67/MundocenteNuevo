<?php $__env->startSection('titulo-pagina'); ?>
	Editar publicación
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
	<?php echo $__env->make('alerts.request', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<!-- <h1>Editar</h1> -->
		<?php echo Form::model($publicacion, ['route'=>['publicacion.update', $publicacion->id], 'method'=>'put','id'=>'publicacion-store']); ?>

			<?php echo $__env->make('publicacion.forms.formulario', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="col-md-1">
		<?php echo Form::submit('Actualizar', ['class'=>'btn btn-primary']); ?>

		<?php echo Form::close(); ?>

  </div>
  <div class="col-md-2 col-md-offset-1">
		<?php echo Form::open(['route'=>['publicacion.destroy', $publicacion->id], 'method'=>'delete']); ?>

		<?php echo Form::submit('Borrar', ['class'=>'btn btn-danger']); ?>

		<?php echo Form::close(); ?>

	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.paneladmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>