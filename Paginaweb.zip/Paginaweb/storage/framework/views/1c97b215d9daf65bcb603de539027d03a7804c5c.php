<!DOCTYPE html>
<html lang="en-US">
<head>
    <meta charset="utf-8">

<style>


</head>
<body>
<h2>Hola  <?php echo e($user->name); ?></h2>

<div>
    Su cuenta  ha  cambiado al estado: <?php echo e($user->estado); ?>

</div>	
<div>
<p>
Cambiaste la configuración recientemente, por lo que tu cuenta de Mundocente <a><?php echo e($user->email); ?></a>
<?php if($user->estado=="activo"): ?>
	ya está <?php echo e($user->estado); ?>.</br>
	<a href="http://grupo2.virtualtic.co/" class="myButton">Ir a tu cuenta</a>
 <?php else: ?>
	ya no está <?php echo e($user->estado); ?>.
<?php endif; ?>
</p>
</div>

</body>
</html>