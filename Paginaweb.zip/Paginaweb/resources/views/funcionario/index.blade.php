@extends('layouts.panelpublicaciones')

@section('titulo-pagina')
	Mis publicaciones
@stop

@section('contenido')
	<h1>Bienvenido publicador</h1>
@stop