<!DOCTYPE html>
<html lang="en-US">
<head>
    <meta charset="utf-8">

<style>


</head>
<body>
<h2>Hola  {{$user->name}}</h2>

<div>
    Bienvenido a Mundocente
</div>	
<div>
<p>
Gracias por registrarte con nosotros. Tu nueva cuenta ha sido configurada y ahora puedes acceder al área de búsqueda y búsquedas avanzadas.


</p>
  <a href="http://grupo2.virtualtic.co/" class="myButton">Ir ha tu cuenta</a>
</div>

</body>
</html>