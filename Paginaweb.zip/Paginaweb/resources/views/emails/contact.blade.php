<!DOCTYPE html>
<html>
<head>
<title>
Una página HTML simple</title>
</head>
<body>

</body>
</html>