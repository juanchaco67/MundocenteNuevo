<?php $__env->startSection('titulo-pagina'); ?>
	Crear publicacion
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
	<?php echo $__env->make('alerts.request', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php echo Form::open(['route'=>'publicacion.store', 'method'=>'post','id'=>'publicacion-store']); ?>

		<?php echo $__env->make('publicacion.forms.formulario', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php echo Form::submit('Registrar', ['class'=>'col-md-offset-5 btn btn-primary', 'title'=>'Registrar esta publicación']); ?>


	<!--
	<form action="<?php echo e(route('usuario.store')); ?>" method="post">
		<?php echo e(csrf_field()); ?>

		<div class="form-group">
			<label for="nombre">Nombre</label>
			<input id="nombre" name="nombre" type="text" class="form-control"></input>
		</div>
		<div class="form-group">
			<label for="correo">Correo</label>
			<input id="correo" name="correo" type="text" class="form-control"></input>
		</div>
		<div class="form-group">
			<label for="contrasena">Contraseña</label>
			<input id="contrasena" name="contrasena" type="password" class="form-control"></input>
		</div>
		<div class="form-group">
			<input type="submit" class="btn btn-primary" value="Registrar"></input>
		</div>
	</form>
	-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.paneladmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>