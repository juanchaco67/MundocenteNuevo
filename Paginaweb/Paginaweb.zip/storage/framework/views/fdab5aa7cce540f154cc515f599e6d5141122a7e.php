<?php echo $__env->make('alerts.request', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php if(isset($usuario)): ?>
	<!-- <h1>Editar</h1>-->
	<?php if($usuario->idrol == 1): ?>
	
	<?php if(Auth::check() && Auth::user()->idrol == 3): ?>
		<?php echo Form::model($usuario, ['route'=>['usuario.update', $usuario->id], 'method'=>'put']); ?>

	<?php else: ?>
		<?php echo Form::model($usuario, ['route'=>['usuario.update', $usuario->id], 'method'=>'put','class'=>'formularioUpdateDocente','name'=>'formularioDocente','onsubmit'=>'return false;']); ?>

	<?php endif; ?>
		 <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" id="token"/>
			<?php echo $__env->make('usuario.forms.docente', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
				<?php if(Auth::check() && Auth::user()->idrol == 3): ?>
					<?php echo Form::submit('Actualizar', ['class'=>'btn btn-primary', 'title'=>'Modificar datos de la cuenta']); ?>

				<?php else: ?>
					<?php echo Form::submit('Actualizar', ['class'=>'submit-editar-docente btn btn-primary', 'title'=>'Modificar datos de la cuenta']); ?>

				<?php endif; ?>
			</div>

		<?php echo Form::close(); ?>

		<?php /*
			<?php echo Form::open(['route'=>['usuario.destroy', $usuario->id], 'method'=>'delete']); ?>

				<?php echo Form::submit('Eliminar', ['class'=>'btn btn-danger']); ?>

			<?php echo Form::close(); ?> 
		*/ ?>
	<?php elseif($usuario->idrol == 2): ?>	
		<?php if(Auth::check() && Auth::user()->idrol == 3): ?>
			<?php echo Form::model($usuario, ['route'=>['usuario.update', $usuario->id], 'method'=>'put']); ?>

		<?php else: ?>
			<?php echo Form::model($usuario, ['route'=>['usuario.update', $usuario->id], 'method'=>'put','name'=>'formularioFuncionario','onsubmit'=>'return false;','class'=>'formularioUpdateFuncionario']); ?>

		<?php endif; ?>
		 <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" id="token"/>

			<?php echo $__env->make('usuario.forms.funcionario', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
				<?php if(Auth::check() && Auth::user()->idrol == 3): ?>
					<?php echo Form::submit('Actualizar', ['class'=>'btn btn-primary', 'title'=>'Modificar datos de la cuenta']); ?>

				<?php else: ?>
					<?php echo Form::submit('Actualizar', ['class'=>'submit-editar-funcionario btn btn-primary', 'title'=>'Modificar datos de la cuenta']); ?>

				<?php endif; ?>
			</div>
			
		<?php echo Form::close(); ?>


	<?php endif; ?>

<?php endif; ?>