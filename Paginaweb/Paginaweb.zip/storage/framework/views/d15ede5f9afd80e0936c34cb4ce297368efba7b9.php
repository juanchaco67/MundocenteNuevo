<!DOCTYPE html>
<html lang="en-US">
<head>
    <meta charset="utf-8">


</head>
<body>

<h2>Hola <?php echo e($notificar['name']); ?></h2>

<div>
    Hay una nueva publicacion que te puede interzar.
</div>	

<div style="width:100%;">
	<div style="float:left;width:50%;">
	 <p><?php echo e($publicacion->nombre); ?> - </p>
	</div>
	<div style="float:left;width:50%;">

	     <?php foreach($lugares as $lugar): ?> 
            <?php foreach($lugar as $ciudad_departamento): ?>              
             <p><?php echo e($ciudad_departamento['departamento']); ?>: <?php echo e($ciudad_departamento['ciudad']); ?> </p>                           
        	<?php endforeach; ?>
       	<?php endforeach; ?>
	 </div>
	 <div>
	     <p><?php echo e($publicacion->resumen); ?></p>
	    <a href="<?php echo e($publicacion->url); ?>">Ver publicacion</a>
	 </div>
	
</div>	

</body>
</html>
    
