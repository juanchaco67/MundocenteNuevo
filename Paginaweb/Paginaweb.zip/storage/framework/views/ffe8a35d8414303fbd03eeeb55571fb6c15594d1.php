<tbody>
	<th><?php echo e($publicacion->nombre); ?></th>
	<th><?php echo e($publicacion->resumen); ?></th>
	<th><?php echo e($publicacion->tipo); ?></th>
	<th><?php echo e($publicacion->fecha_publicacion); ?></th>
	<th><?php echo e($publicacion->fecha_cierre); ?></th>
	<th>
		<?php echo link_to_route('publicacion.edit', $title = 'Editar', $parameters = $publicacion->id, $atrributes = ['class' => 'btn btn-primary', 'title'=>'Editar esta publicación']); ?>

		<?php if($publicacion->estado == 'activa'): ?>
			<button class="borrar btn btn-default" title="Borrar esta publicación" data-toggle="modal" data-target="#<?php echo e($publicacion->id); ?>">
			    ¿Borrar?
			</button>

			<div class="modal fade" id="<?php echo e($publicacion->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
			    <div class="modal-dialog">
			        <div class="modal-content">
			            <div class="modal-header">
			            	<button type="button" class="close" data-dismiss="modal">&times;</button>
			                <h4 class="text-center modal-title">Borrar publicación</h4>
			            </div>
			            <div class="modal-body">
			            	<div>
				                <p>¿Seguro que desea eliminar la siguiente publicación?</p>
				                <ul>
				                	<li>
				                		<h4>Nombre </h4>
				                			<p><?php echo e($publicacion->nombre); ?></p>
				                		</li>
				                	<li>
				                		<h4>Resumen </h4>
				                			<p><?php echo e($publicacion->resumen); ?></p></li>
				                	<li>
				                		<h4>Descripción </h4>
				                		<p><?php echo e($publicacion->descripcion); ?></p>
				                	</li>
				                </ul>
				            </div>
			            </div>
			            <div class="modal-footer">
			                <?php echo Form::open(['route'=>['publicacion.destroy', $publicacion->id], 'method'=>'delete']); ?>

			                <a class="btn btn-default" data-toggle="modal" data-target="#<?php echo e($publicacion->id); ?>">
					    		Cancelar
							</a>
							<?php echo Form::submit('Borrar', ['class'=>'btn btn-danger']); ?>

							<?php echo Form::close(); ?>

			            </div>
			        </div>
			    </div>
			</div>

		<?php else: ?>
			<button class="btn btn-default" data-toggle="modal" data-target="#<?php echo e($publicacion->id); ?>">
				    ¿Recuperar?
				</button>

				<div class="modal fade" id="<?php echo e($publicacion->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
				    <div class="modal-dialog">
				        <div class="modal-content">
				            <div class="modal-header">
				            	<button type="button" class="close" data-dismiss="modal">&times;</button>
				                <h4 class="text-center modal-title">Recuperar publicación</h4>
				            </div>
				            <div class="modal-body">
				            	<div>
					                <p>¿Seguro que desea recuperar la siguiente publicación?</p>
					                <ul>
					                	<li>
					                		<h4>Nombre </h4>
					                			<p><?php echo e($publicacion->nombre); ?></p>
					                		</li>
					                	<li>
					                		<h4>Resumen </h4>
					                			<p><?php echo e($publicacion->resumen); ?></p></li>
					                	<li>
					                		<h4>Descripción </h4>
					                		<p><?php echo e($publicacion->descripcion); ?></p>
					                	</li>
					                </ul>
					            </div>
				            </div>
				            <div class="modal-footer">
				                <?php echo Form::open(['action'=>['PublicacionController@recuperar', $publicacion->id]]); ?>

				                <a class="btn btn-default" data-toggle="modal" data-target="#<?php echo e($publicacion->id); ?>">
						    		Cancelar
								</a>
								<?php echo Form::submit('Recuperar', ['class'=>'btn btn-primary']); ?>

								<?php echo Form::close(); ?>

				            </div>
				        </div>
				    </div>
				</div>


		<?php endif; ?>
		
	</th>
</tbody>