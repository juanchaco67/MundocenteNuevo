<input name="rol" value="funcionario" hidden></input>
<?php echo $__env->make('usuario.forms.registro', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php if(isset($establecimientos)): ?>
		<legend>Universidad/Entidad</legend>
	  	<fieldset>
	      	<div class="form-group">
			  <label for="sel1">Pertenezco a:</label>
			  <select name="establecimiento" class="form-control" id="sel1">
				<?php foreach($establecimientos as $establecimiento): ?>
					<?php if(!isset($usuario)): ?>
				    	<option value="<?php echo e($establecimiento->id); ?>"><?php echo e($establecimiento->nombre); ?></option>
				    <?php else: ?>
				    	<?php if($usuario->funcionario): ?>
					    	<?php if($usuario->funcionario->establecimiento_id == $establecimiento->id): ?>
					    		<option value="<?php echo e($establecimiento->id); ?>" selected><?php echo e($establecimiento->nombre); ?></option>
					    	<?php else: ?>
					    		<option value="<?php echo e($establecimiento->id); ?>"><?php echo e($establecimiento->nombre); ?></option>   		
					    	<?php endif; ?>
					    <?php endif; ?>
				    <?php endif; ?>
				<?php endforeach; ?>
			  </select>
			</div>
	  	</fieldset>
	<?php endif; ?>
<?php if(isset($usuario)): ?>
	<?php if($usuario->estado == "activo"): ?>
	
		<div class="form-group">
			<label for="desactivar">Desactivar esta cuenta</label>
			<?php if($usuario->estado === 'inactivo'): ?>
				<input name="desactivar" id="" value="desactivar" type="checkbox" checked></input>
			<?php else: ?>
				<input name="desactivar" id="desactivar" value="desactivar" type="checkbox"></input>
			<?php endif; ?>
		</div>
	<?php else: ?>

		<div class="form-group">
			<label for="activar">Activar esta cuenta</label>
			<?php if($usuario->estado === 'activo'): ?>
				<input name="activar" id="" value="activar" type="checkbox" checked></input>
			<?php else: ?>
				<input name="activar" id="activar" value="activar" type="checkbox"></input>
			<?php endif; ?>
		</div>
	<?php endif; ?>
<?php endif; ?>