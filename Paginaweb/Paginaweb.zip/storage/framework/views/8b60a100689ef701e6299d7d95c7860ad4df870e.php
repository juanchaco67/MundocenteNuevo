<div class="form-group">
	<?php echo Form::label('Nombre'); ?>

	<?php echo Form::text('name', null, ['class'=>'txtNombre form-control', 'placeholder'=>'Ingresa el nombre de usuario', 'autofocus'=>'autofocus']); ?>

	
</div>
<div class="form-group">
	<?php echo Form::label('Correo'); ?>

	<!-- <input class="form-control" type="email" name="email" placeholder="Ingresa el correo"> -->
	<?php echo Form::text('email', null, ['class'=>'form-control', 'placeholder'=>'Ingresa el correo','name'=>'email']); ?>

</div>
<div class="form-group">
	<?php echo Form::label('Contraseña'); ?>

	<?php echo Form::password('password', ['class'=>'form-control', 'placeholder'=>'Ingresa la contraseña','name'=>'password']); ?>

</div>