<input name="rol" value="admin" id="rol"  hidden></input>
<?php echo $__env->make('usuario.forms.registro', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>