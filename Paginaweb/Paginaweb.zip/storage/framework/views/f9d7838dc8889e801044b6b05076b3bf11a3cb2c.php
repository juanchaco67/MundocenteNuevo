<?php if(Auth::check() && Auth::user()->idrol == 3): ?>

	<?php if(isset($publicadores)): ?>
		<?php if($publicadores): ?>
			<div class="form-group col-md-12">
				<?php echo Form::label('Publicador'); ?>

				<select name="publicador" class="form-control">
					<?php foreach($publicadores as $publicador): ?>
						<?php /*<h3><?php echo e($publicador->user->name); ?></h3>*/ ?>
						<option value="<?php echo e($publicador->id); ?>"><?php echo e($publicador->user->name); ?></option>
					<?php endforeach; ?>
				</select>
			</div>
		<?php else: ?>
			<h3>No existen publicadores</h3>
		<?php endif; ?>
	<?php endif; ?>
<?php endif; ?>

<div class="form-group col-md-6">
	<?php echo Form::label('Nombre'); ?>

	<?php echo Form::text('nombre', null, ['class'=>'form-control', 'placeholder'=>'Ingresa el nombre de la publicación']); ?>

</div>
<div class="form-group col-md-6">
	<?php echo Form::label('Resumen'); ?>

	<?php echo Form::text('resumen', null, ['class'=>'form-control', 'placeholder'=>'Ingresa el resumen de la publicación']); ?>

</div>
<div class="form-group col-md-6">
	<?php echo Form::label('Descripcion'); ?>

	<?php echo Form::textarea('descripcion', null, ['class'=>'form-control', 'placeholder'=>'Ingresa la descripción de la publicación']); ?>

</div>
<div class="form-group col-md-6">
	<?php echo Form::label('Url'); ?>

	<?php echo Form::text('url', null, ['class'=>'form-control', 'placeholder'=>'Ingresa la descripción de la publicación']); ?>

</div>
<div class="form-group col-md-6">
	<?php echo Form::label('Tipo'); ?>

	<?php echo Form::select('tipo', array('revista' => 'Revista', 'convocatoria' => 'Convocatoria', 'evento' => 'Evento'), null, ['class'=>'form-control']); ?>

</div>
<div class="form-group col-md-12">

	<?php echo Form::label('Lugar'); ?>

	<?php if(isset($departamentos)): ?>
	
		<div class="form-group">

			<select  id="lugar" class="form-control">
				<?php foreach($departamentos as $departamento): ?>
					<optgroup label="<?php echo e($departamento->nombre); ?>">
					<?php if(!isset($user)): ?>
					
  					
				    <?php else: ?>
				    	<?php foreach($ciudades as $ciudad): ?>
  						<?php if($ciudad->ubicacion_id==$departamento->id): ?>
  						<option value="<?php echo e($ciudad->id); ?>" name="<?php echo e($ciudad->nombre); ?>"><?php echo e($ciudad->nombre); ?></option>
					    
					 	<?php endif; ?>
				    	<?php endforeach; ?>
				    
				    	
				    	--}}
				    <?php endif; ?>
				     </optgroup>
				<?php endforeach; ?>
			  </select>
		</div>
	<?php else: ?>
		<h6>No hay lugares</h6>
	<?php endif; ?>
</div>
<?php if(isset($verificar)): ?>
<div class="scrollbar municipios-scroll" id="style-1" style="display:inline-block;">
	<div id="municipios" class="force-overflow" style="display:inline-block; width:100%; height:50px;">
	<?php foreach($ciudades_selecciondas as $ciudades): ?>
	  <div style="height:1px;display:inline-block;position:relative;" class="alert alert-success"><span style="position:relative;bottom:10px;"><?php echo e($ciudades->nombre); ?></span><a style="position:absolute;left:90%;top:0%;" href="#" id="<?php echo e($ciudades->id); ?>" class="eliminar-lugar close" data-dismiss="alert" aria-label="close">&times;</a></div>
	  <input type="hidden" name="lugar[]" class="eliminar-hidden" id="hidden<?php echo e($ciudades->id); ?>" value="<?php echo e($ciudades->id); ?>"/>
	 
	<?php endforeach; ?>
</div>	    
</div>	 	
 <?php else: ?>
<div class="scrollbar municipios-scroll" id="style-1" style="display:none;">
	<div id="municipios" class="force-overflow" style="display:none; width:100%; height:50px;">
	 
	 </div>
 </div>
 	<?php endif; ?>

<div class="col-md-12">
	<?php if(isset($fecha_publicacion)): ?>
		<div class="form-group col-md-6">
			<?php echo Form::label('Fecha inicio'); ?>

			<?php echo Form::date('fecha_publicacion', $fecha_publicacion, ['class' => 'form-control']); ?>

		</div>
	<?php else: ?>
		<div class="form-group col-md-6">
			<?php echo Form::label('Fecha inicio'); ?>

			<?php echo Form::date('fecha_publicacion', \Carbon\Carbon::now(), ['class' => 'form-control']); ?>

		</div>
	<?php endif; ?>

	<?php if(isset($fecha_cierre)): ?>
		<div class="form-group col-md-6">
			<?php echo Form::label('Fecha cierre'); ?>

			<?php echo Form::date('fecha_cierre', $fecha_cierre, ['class' => 'form-control']); ?>

		</div>
	<?php else: ?>
		<div class="form-group col-md-6">
			<?php echo Form::label('Fecha cierre'); ?>

			<?php echo Form::date('fecha_cierre', \Carbon\Carbon::now(), ['class' => 'form-control']); ?>

		</div>
	<?php endif; ?>
</div>

<div class="form-group col-md-12">
	<?php echo Form::label('Aplica para'); ?>

	<?php if(isset($areas)): ?>
	<select  id="area-publicacion" class="form-control">
	<?php foreach($areas as $area): ?>
  		<option value="<?php echo e($area->id); ?>" name="<?php echo e($area->nombre); ?>"><?php echo e($area->nombre); ?></option>
	<?php endforeach; ?>

	</select>

		
	<?php else: ?>
		<h1>Sin areas</h1>
	<?php endif; ?>
</div>


<?php if(isset($verificar)): ?>
<div class="scrollbar areas-aparecer-scroll" id="style-1" style="display:inline-block;">
	<div id="areas-aparecer" class="force-overflow" style="display:inline-block; width:100%; height:50px;">
	<?php foreach($areas as $area): ?>

		<?php if(in_array($area->id, $areas_usuario)): ?>

					 <div style="height:1px;display:inline-block;position:relative;" class="alert alert-success"><span style="position:relative;bottom:10px;"><?php echo e($area->nombre); ?></span><a style="position:absolute;left:90%;top:0%;" href="#" id="area-aparecer<?php echo e($area->id); ?>" class="eliminar-area close" data-dismiss="alert" aria-label="close">&times;</a></div>
				 <input type="hidden" name="areas[]" class="areas-eliminar-hidden" id="hidden-areas-<?php echo e($area->id); ?>" value="<?php echo e($area->id); ?>"/>	
			<?php endif; ?>
	<?php endforeach; ?>
</div>	
</div>	    	
 <?php else: ?>
<div class="scrollbar areas-aparecer-scroll" id="style-1" style="display:none;">
	<div id="areas-aparecer" class="force-overflow" style="display:none; width:100%; height:50px;">
	 
	 </div>
 </div>
 	<?php endif; ?>