    <!-- Bootstrap Core CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('bower_components/bootstrap/dist/css/bootstrap.min.css')); ?>"> 
    <!-- <link href="../bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet"> -->

    <!-- MetisMenu CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('bower_components/metisMenu/dist/metisMenu.min.css')); ?>"> 
    <!-- <link href="../bower_components/metisMenu/dist/metisMenu.min.css" rel="stylesheet"> -->

    <!-- Timeline CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('dist/css/timeline.css')); ?>"> 
    <!-- <link href="../dist/css/timeline.css" rel="stylesheet"> -->

    <!-- Custom CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('dist/css/sb-admin-2.css')); ?>"> 
    <!-- <link href="../dist/css/sb-admin-2.css" rel="stylesheet"> -->

    <!-- Morris Charts CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('bower_components/morrisjs/morris.css')); ?>"> 
    <!-- <link href="../bower_components/morrisjs/morris.css" rel="stylesheet"> -->

    <!-- Custom Fonts -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('bower_components/font-awesome/css/font-awesome.min.css')); ?>"> 
    <!-- <link href="../bower_components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css"> -->
