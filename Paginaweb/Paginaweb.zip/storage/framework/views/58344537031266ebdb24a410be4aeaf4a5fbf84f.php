<div class="filtros panel-group" id="accordion">
  <!--<div class="panel panel-default">
    <div class="panel-heading">
      <h4 class="panel-title">
        <a data-toggle="collapse" data-parent="#accordion" href="#collapse1">
        Búsqueda</a>
      </h4>
    </div>
    <div id="collapse1" class="panel-collapse collapse in">
      <div class="panel-body">Busqueda rapida</div>
    </div>
  </div> -->
  <div class="panel panel-default">
    <div class="panel-heading">
      <h4 class="panel-title">
        <a data-toggle="collapse" data-parent="#accordion" href="#collapse2">
        Tipos publicación</a>
      </h4>
    </div>
    <div id="collapse2" class="panel-collapse collapse">
      <div class="panel-body">
        <ul>
            <li>
                <input type="checkbox" id="revista" name="tipo" value="revista"><label for="revista">Revistas</label></input>
            </li>                   
            <li>
                <input type="checkbox" id="convocatoria" name="tipo" value="convocatoria"><label for="convocatoria">Convocatorias</label></input>
            </li>
            <li>
                <input type="checkbox" id="evento" name="tipo" value="evento"><label for="evento">Eventos</label></input>
            </li>
        </ul>
      </div>
    </div>
  </div>

  <div class="panel panel-default">
    <div class="panel-heading">
      <h4 class="panel-title">
        <a data-toggle="collapse" data-parent="#accordion" href="#collapse3">
        Áreas de publicación</a>
      </h4>
    </div>
    <div id="collapse3" class="panel-collapse collapse">
      <div class="barra-scroll panel-body">
        <?php if(isset($areas)): ?>
          <ul>
            <?php foreach($areas as $area): ?>
              <li>
                  <input type="checkbox" id="area<?php echo e($area->id); ?>" name="areas" value="<?php echo e($area->id); ?>"><label for="area<?php echo e($area->id); ?>"><?php echo e($area->nombre); ?></label></input>
              </li>
            <?php endforeach; ?>
          </ul>
        <?php endif; ?>
      </div>
    </div>
  </div>

   <div class="panel panel-default">
    <div class="panel-heading">
      <h4 class="panel-title">
        <a data-toggle="collapse" data-parent="#accordion" href="#collapse4">
        Ciudades</a>
      </h4>
    </div>
    <div id="collapse4" class="panel-collapse collapse">
      <div class="barra-scroll panel-body">
        <?php if(isset($lugares)): ?>
          <ul>
            <?php foreach($lugares as $lugar): ?>
              <li>
                  <input type="checkbox" id="lugar<?php echo e($lugar->id); ?>" name="lugares" value="<?php echo e($lugar->id); ?>"><label for="lugar<?php echo e($lugar->id); ?>"><?php echo e($lugar->nombre); ?></label></input>
              </li>
            <?php endforeach; ?>
          </ul>
        <?php endif; ?>
      </div>
    </div>
  </div>

   <div class="panel panel-default">
    <div class="panel-heading">
      <h4 class="panel-title">
        <a data-toggle="collapse" data-parent="#accordion" href="#collapse5">
        Universidades/Entidades</a>
      </h4>
    </div>
    <div id="collapse5" class="panel-collapse collapse">
      <div class="barra-scroll panel-body">
        <?php if(isset($establecimientos)): ?>
          <ul>
            <?php foreach($establecimientos as $establecimiento): ?>
              <li>
                  <input type="checkbox" id="establecimiento<?php echo e($establecimiento->id); ?>" name="establecimientos" value="<?php echo e($establecimiento->id); ?>"><label for="establecimiento<?php echo e($establecimiento->id); ?>"><?php echo e($establecimiento->nombre); ?></label></input>
              </li>
            <?php endforeach; ?>
          </ul>
        <?php endif; ?>
      </div>
    </div>
  </div>

</div>