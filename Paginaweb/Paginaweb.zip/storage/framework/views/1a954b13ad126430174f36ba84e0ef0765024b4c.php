<!DOCTYPE html>
<html lang="en-US">
<head>
    <meta charset="utf-8">


</head>
<body>
<h2>Bienvenido a Mundocente!</h2>

<div>
    Bienvenido  <?php echo e($user->name); ?>

</div>	
<div>
<p>
La configuracion de tu cuenta Mundocente <?php echo e($user->email); ?>


<?php if($user->estado=="activo"): ?>
esta activada, ya puedes comenzar ha utilizar nuestros servicios
<?php else: ?>
	no esta activada. Te enviaremos un correo informandote de su activacion.
<?php endif; ?>
</p>
  <a href="http://grupo2.virtualtic.co/" class="myButton">Ir a tu cuenta</a>
</div>

</body>
</html>