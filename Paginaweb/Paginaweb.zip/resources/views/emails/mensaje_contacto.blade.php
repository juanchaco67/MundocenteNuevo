<!DOCTYPE html>
<html lang="en-US">
<head>
    <meta charset="utf-8">


</head>
<body>
<h2>Hola  Admin</h2>

<div>
    Mensaje de {{$nombre}}
</div>	
<div>
<p>
	Correo: {{$correo}}
</p>
<p>
	Asunto: {{$asunto}}
</p>
<p>
	Mensaje: {{$mensaje}}
</p>

  <a href="http://grupo2.virtualtic.co/" class="myButton">Ir Mundocente</a>
</div>

</body>
</html>