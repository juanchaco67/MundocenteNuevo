<!DOCTYPE html>
<html lang="en-US">
<head>
    <meta charset="utf-8">


</head>
<body>
<h2>Bienvenido a Mundocente!</h2>

<div>
    Bienvenido a {{ $user->name }}
</div>	
<div>
<p>
Gracias por registrarte con nosotros. Tu nueva cuenta ha sido configurada y ahora puedes acceder al área de búsqueda y búsquedas avanzadas.


</p>
  <a href="http://grupo2.virtualtic.co/" class="myButton">Ir a tu cuenta</a>
</div>

</body>
</html>